'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const html=fs.readFileSync('app/src/main/assets/selector.html','utf8');
const start=html.indexOf('function getDisplayResults('),end=html.indexOf('function renderResults(){',start);
assert.ok(start>=0&&end>start);
const rows=[
 {id:1,f:{fixture:{date:'2026-11-16T13:00:00Z'}}},
 {id:2,f:{fixture:{date:'2026-11-16T10:15:00Z'}}},
 {id:3,f:{fixture:{date:'2026-11-16T10:50:00Z'}}},
 {id:4,f:{fixture:{date:'2026-11-16T09:00:00Z'}}}];
const ctx={app:{ranked:rows},mode:'original',Date};ctx.el=()=>({value:ctx.mode});vm.createContext(ctx);
vm.runInContext(html.slice(start,end)+'globalThis.get=getDisplayResults;',ctx);
const names=()=>Array.from(ctx.get(new Date('2026-11-16T10:00:00Z').getTime()),x=>x.id);
assert.deepEqual(names(),[1,2,3,4]);
ctx.mode='kickoff';assert.deepEqual(names(),[4,2,3,1]);
ctx.mode='nearest';assert.deepEqual(names(),[2,3,1,4]);
assert.deepEqual(Array.from(ctx.get(new Date('2026-11-16T10:20:00Z').getTime()),x=>x.id),[3,1,2,4]);
assert.deepEqual(rows.map(x=>x.id),[1,2,3,4]);
assert.ok(html.includes('清除全部勾选')&&html.includes('nativeSelectById(id,false)'));
console.log('PASS: original, historical kickoff ascending, current-time nearest future-first, past at end, read-only sorting, clear all');
