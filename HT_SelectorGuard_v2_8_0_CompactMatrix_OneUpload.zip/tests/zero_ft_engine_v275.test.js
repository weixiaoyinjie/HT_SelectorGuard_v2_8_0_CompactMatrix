'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),E=require('../app/src/main/assets/zero_ft_engine.js');
const f={fixture:{id:99,date:'2026-11-25T10:00:00Z',status:{short:'NS'}},league:{type:'League',name:'League'},teams:{home:{id:1},away:{id:2}}};
const mk=(name,odd)=>({name,values:[{value:'1:0',odd}]});
const row=(id,book,bets,update='2026-11-24T12:00:00Z')=>({fixture:{id},update,bookmakers:[{name:book,bets}]});
const quoteRows=[row(99,'Bet365',[mk('Correct Score',6),mk('Half Time Correct Score',3),mk('Second Half Correct Score',2),mk('Exact Score - 1st Half',2),mk('Correct Score / Both Teams Score',20)]),row(100,'Bet365',[mk('Correct Score',50)]),row(99,'OtherBook',[mk('Correct Score',80)]),row(99,'Bet365',[mk('Exact Score',7)],'2026-11-24T13:00:00Z'),row(99,'Bet365',[mk('Correct Score',5)],'2026-11-24T10:00:00Z')];
assert.equal(E.extract(quoteRows,99).quotes['1-0'].odd,7);assert.equal(E.kind('Correct Score - 2nd Half'),null);assert.equal(E.kind('Full Time Correct Score'),'score');assert.equal(E.kind('Goals Over/Under'),'total');assert.equal(E.kind('1st Half Goals Over/Under'),null);
const price=E.extract([row(99,'Bet365',[{name:'Correct Score',values:E.scores.map(value=>({value,odd:8}))},{name:'Match Winner',values:[{value:'Home',odd:2},{value:'Draw',odd:3},{value:'Away',odd:5}]},{name:'Goals Over/Under',values:[{value:'Under 3.5',odd:1.2},{value:'Over 3.5',odd:5}]}])],99);
function games(id,isHome,fn){return Array.from({length:20},(_,i)=>{const [gf,ga]=fn(i),s=isHome?[gf,ga]:[ga,gf];return {fixture:{id:id*100+i,date:new Date(Date.parse(f.fixture.date)-(i+1)*864e5).toISOString(),status:{short:'FT'}},teams:{home:{id:isHome?id:10+i},away:{id:isHome?10+i:id}},league:{type:'League',name:'League'},score:{halftime:{home:0,away:0},fulltime:{home:s[0],away:s[1]}}};});}
function research(h,a,prices=price){return E.analyze({fixture:f,homeHistory:games(1,true,h),awayHistory:games(2,false,a),prices,htOdd:2.1,events:{}});}
const home=research(i=>[i%2+1,0],i=>[0,i%2+1]);assert.deepEqual(home.combo.scores,['1-0','2-0','0-0']);assert.equal(home.grade,'C');assert.equal(home.home.one,.5);assert.equal(home.home.two,.5);assert.equal(home.away.zero,1);assert.equal(home.home.ht00N,20);assert.equal(home.home.ht00Dist['1-0'],10);assert.equal(home.combo.cost,3/8);
const counter=research(i=>[i%2+1,1],i=>[1,i%2+1]);assert.deepEqual(counter.combo.scores,['1-0','1-1','2-0']);
const weak=research(()=>[0,0],()=>[0,0]);assert.deepEqual(weak.combo.scores,['0-0','1-0','0-1']);
const away=research(()=>[0,1],()=>[1,0]);assert.deepEqual(away.combo.scores,['0-1','0-2','0-0']);
assert.equal(research(()=>[3,2],()=>[2,3]).grade,'PASS');assert.equal(research(()=>[1,0],()=>[0,1],{quotes:{},market:{}}).combo.cost,null);
const event=E.eventSummary([{type:'Goal',detail:'Normal Goal',team:{id:1},time:{elapsed:90,extra:5}},{type:'Goal',detail:'Missed Penalty',team:{id:2},time:{elapsed:80}}],1,2);assert.deepEqual(event,{home:1,away:0,lateHome:1,lateAway:0});assert.equal(E.eventSummary([],1,2),null);
const html=fs.readFileSync('app/src/main/assets/selector.html','utf8');assert(html.includes('zero_ft_engine.js'));assert(html.includes('await scanZeroFT()'));assert(html.includes('ZeroFTEngine.extract(rows,id)'));assert(html.includes('q?money(q.odd)'));assert(html.includes("api('fixtures',{ids:batch.join('-')})"));
console.log('PASS: full-time engine 5 structures, true fixture/book/period separation, latest quote, missing data, conditional history, late goal and UI wiring');
