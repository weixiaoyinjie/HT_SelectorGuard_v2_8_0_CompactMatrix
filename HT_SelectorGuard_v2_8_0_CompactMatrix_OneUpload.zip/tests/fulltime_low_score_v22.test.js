'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const E=require('../app/src/main/assets/fulltime_engine.js');
const date='2026-11-25T15:00:00Z';
const fixture={fixture:{id:123,date,status:{short:'NS'}},league:{type:'League',name:'Premier League'},teams:{home:{id:10},away:{id:20}}};
function game(i,team,home,[h,a]){return {fixture:{id:team*10000+i,date:new Date(Date.parse(date)-(i+1)*86400e3).toISOString(),status:{short:'FT'}},league:{type:'League',name:'Premier League'},teams:{home:{id:home?team:1000+i},away:{id:home?1000+i:team}},score:{fulltime:{home:h,away:a}}};}
function histories(hSc,aSc){return {homeHistory:Array.from({length:20},(_,i)=>game(i,10,true,hSc(i))),awayHistory:Array.from({length:20},(_,i)=>game(i,20,false,aSc(i)))};}
function prices(book='Bet365',scoreOdds=7,betName='Correct Score'){return [{bookmakers:[{name:book,bets:[
 {id:10,name:betName,values:['0-0','1-0','2-0','1-1','2-1'].map(value=>({value,odd:String(scoreOdds)}))},
 {id:1,name:'Match Winner',values:[{value:'Home',odd:'1.70'},{value:'Draw',odd:'3.50'},{value:'Away',odd:'5.00'}]},
 {id:2,name:'Goals Over/Under',values:[{value:'Over 3.5',odd:'5.00'},{value:'Under 3.5',odd:'1.20'}]}
 ]}]}];}
function analyze(hist,oddsRows=prices(),extra={}){return E.analyze({fixture,...hist,oddsRows,exactBetIds:[10],...extra});}
const one=histories(i=>i%5<3?[1,1]:[2,0],i=>i%5<3?[1,1]:[2,0]);
const r1=analyze(one);
assert.equal(r1.combo.id,'clean','one-goal home profile should prefer 1-0/2-0/1-1');
assert.deepEqual(r1.combo.scores,['1-0','2-0','1-1']);
assert.equal(r1.canSelect,true);
assert.equal(r1.home.exactOneRate,.6);
assert.equal(r1.away.concedeTwoPlus,.4);
const two=histories(i=>i%5<2?[1,0]:[2,1],i=>i%5<2?[1,0]:[2,1]);
const r2=analyze(two);
assert.equal(r2.combo.id,'home-attack','2-goal home profile and away concede-2 should prefer 2-1 cover');
assert.deepEqual(r2.combo.scores,['1-0','2-0','2-1']);
assert.equal(r2.canSelect,true);
const zero=histories(i=>i%2===0?[0,0]:[1,0],()=>[0,0]);
const rz=analyze(zero);
assert.equal(rz.grade,'PASS');
assert.match(rz.reason,/0-0|零进球/);
const blowout=histories(()=>[3,1],()=>[3,2]);
assert.equal(analyze(blowout).grade,'PASS','open 4+ match must be rejected');
assert.equal(analyze(one,prices(),{minOdd:8}).canSelect,false,'user FT minimum odds must be respected');
assert.equal(analyze(one,prices('Bet365',2.4),{minOdd:9,ignorePriceFloor:true}).canSelect,true,'FT v2.5 shows genuine low-priced scores without minimum odds gate');
assert.equal(analyze(one,prices('OtherBook',2.4),{ignorePriceFloor:true}).canSelect,false,'FT price-free mode still requires authentic Bet365 odds');
assert.equal(analyze(one,prices('OtherBook')).canSelect,false,'no fake Bet365 FT odds');
assert.equal(analyze(one,prices('Bet365',7,'Half Time Correct Score')).canSelect,false,'never treat HT score market as FT even with ID collision');
const modified=fs.readFileSync('app/src/main/java/com/htlive/monitor/MonitorService.java','utf8');
const alert=fs.readFileSync('app/src/main/java/com/htlive/monitor/AlertNotifier.java','utf8');
assert.match(modified,/new int\[\]\{60,75,85\}/);
assert.match(modified,/AlertNotifier\.postFullTimeMark/);
assert.match(alert,/if\(!emit\(ctx,"⏱ 第"\+mark/);
assert.match(alert,/if\(!p\.edit\(\)\.putBoolean\(key,true\)\.commit\(\)\)return false;/);
console.log('PASS: FT score profiles 1-0/2-0/1-1 and 1-0/2-0/2-1, risk PASS, true FT quotes, reminders');
