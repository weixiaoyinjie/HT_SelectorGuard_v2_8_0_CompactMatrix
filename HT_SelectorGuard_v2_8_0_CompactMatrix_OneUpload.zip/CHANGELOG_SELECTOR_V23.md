# v2.3 · 候选勾选预警 / 筛选结果保留修复

基于 `HT_SelectorGuard_v2_2_FT_LowScore_60_75_85_NewRepo.zip` 原始完整源码进行**定向修复**，未改变半场/全场筛选引擎、预警频率、比分计划、通知排版或手表端代码。

## 解决的问题

1. 半场和全场扫描结果的每一张 **A/B 候选**卡片都保留“勾选即加入预警”，并新增可直接点击的 **🔔 直接加入预警**按钮。原生监控接受后才显示勾选成功/已加入，点已加入可取消，失败则明确提示。C/PASS 仍不可勾选（属于风险排除规则）。原生监控上限仍为同时 12 场。
2. 在“打开实时预警”与“打开筛选”之间切换时，改用 `FLAG_ACTIVITY_REORDER_TO_FRONT` 复用页面，不再主动 `finish()` 退出筛选页。
3. 半场/全场分别保存独立的完整候选快照，保存于 Android 应用私有空间的 gzip 文件中，避免 WebView localStorage 容量不足。包括扫描时的卡片、赔率、研判、7场历史缓存和排序设置；**不保存 API Key / OpenAI Key 到候选快照**。页面被 Android 回收/重启也可恢复，日期和快照时间醒目标识。浏览器版本尝试 localStorage 作为降级存储。
4. 切回筛选页时同步重新读取原生监控名单，修正从监控页删除比赛后勾选仍残留的问题。
5. Android `versionCode 14`，`versionName 4.1.1-HTFT-candidate-alert-cache-fix`，保持相同 applicationId 与开发签名以便升级。

## 明确保留

- 半场/全场筛选算法和 PASS、0-0 风险门槛未改。
- 全场 60/75/85 三段通知、半场预警及 Watch8 相关核心逻辑均未改。
- 比赛模式仍按单场锁定，预警须满足原来的实况、时间及通知权限条件。
- 勾选不代表立即发送预警：开赛第3分钟前预约；已过窗口、API Key 无效或超过12场可能被拒绝。

## 使用

**新建空 GitHub 仓库时**，先将 ZIP 解压后上传完整目录（包括 `.github/workflows/build-apk.yml`），GitHub 才会有构建工作流。**已有 v2.2 构建工作流时**，可使用另外提供的“旧工作流兼容文件名”ZIP 覆盖仓库原来的 v2.2 ZIP，触发已有工作流并解压 v2.3 代码；该兼容文件名虽然是 v2.2，但内部是 v2.3 最新修复版。更新后的工作流可识别 `HT_SelectorGuard_v2_3_CandidateAlert_Persist_OneUpload.zip`。也可直接解压后提交整个源码仓库以触发 `app/**` 的构建。安装手机新 APK 保留应用原有本机数据；若旧版已经切出预警导致的历史候选不在内存或备份，**无法无中生有恢复旧版未保存的扫描结果**，新版本完成一次扫描后开始保留。

## 测试

- `node tests/selector_v23_state.test.js`：半场/全场独立保存与切换、冷启动恢复、直接预警勾选/取消及原生名单同步。
- `javac ... SelectorSnapshotStore.java ... SelectorSnapshotStoreTest.java`：gzip 读写与隔离及非法参数。
- `tests/*.test.js`、`tests/selector/*.js`、`tests/selector/*.cjs`：既有静态筛选与通知规则回归。
