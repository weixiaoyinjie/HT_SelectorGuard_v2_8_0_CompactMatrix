# Watch8 ScorePath v3.8 · 圆形表盘精简预警

从用户提供的 `Watch8_ScorePath_RELIABLE_v3_7_OneUpload.zip` 原样升级，**不变更手机端赛况监控、赔率/风险判断、通知正文、比分策略或 OCR**。手机、手表统一 `versionCode 10`；沿用原包名与测试签名（仅供私有开发仓库）。

## 手表预警新布局

- 手表原生通知：赛况时间 / 比分 / 我的真实下单比分及状态 / 守分风险提醒，优先显示关键信息。
- 点进通知：一个完整圆形屏幕的高密度预警页。上窄区是类型和时间，中间显示比分与最多三张主单/保险单（命中中、待达、失效、已结、待核），下窄区是风险、动作、采集是否有效；适配圆形弦宽。
- 手指向上滑动第一屏（或点按）：接续阅读完整手机通知、完整 AI 详细分析、数据源时效和「已查看」确认。仅在长报告时继续滑动。
- 数据源没有统计时提示缺失/滞后，不猜测不存在的数据，也不保证下一球或自动结算。
- 手表首页的「查看同步赛况」也把下单比分优先显示在统计数据前面。

**限制：** 系统提供的原生通知浮层高度由 Wear OS 控制，不保证无需展开可显示所有三张。点开通知后的自定义圆形页才是一屏设计。不同字体缩放和 Watch8 实际显示分辨率仍需要真机验证。

## GitHub 编译 — 推荐

### 已有仓库并使用旧 v3.7 CI（单次 ZIP 替换）

使用文件名精确为 `Watch8_ScorePath_RELIABLE_v3_7_OneUpload.zip` 的「旧工作流兼容版」，**替换仓库根目录同名旧 ZIP**，并触发旧 workflow：`Build Watch8 44mm Phone and Wear APKs`。虽然外部文件名为 v3.7（兼容 CI 监听路径），内部代码和 APK 版本都是 v3.8，旧 CI 解压后可编译。

### 新仓库（或升级已有 GitHub Actions）

解压 `Watch8_ScorePath_ROUND_v3_8_OneUpload.zip`，把文件夹内所有文件（包括隐藏的 `.github/workflows/build-apk.yml`）上传到仓库根目录，运行 GitHub Actions 的同名 workflow。

也可先把更新版 `.github/workflows/build-apk.yml` 放到旧仓库，再上传新命名的 v3.8 ZIP。

GitHub Actions 成功后会提供 `HT-Watch8-44mm-PHONE-APK` 与 `HT-Watch8-44mm-WEAR-APK` 两个产物。手机和手表均升级 v3.8 才能显示结构化比分状态。

## 快速测试

1. 先在手表开启应用通知权限、手机与手表配对并确认连接。
2. 点手表首页「查看同步赛况」确认比赛及下注比分已同步。
3. 打开手表里的「HT 赛况预警」→「测试手表通知」；测试为虚构比赛 `1-0 / 2-0 / 1-1`，验证圆形排版、预警颜色与上滑详情。
4. 检查真实比赛通知的下注比分，与手机端配置进行逐场核对。

开发者本地 Gradle 命令：`gradle :app:assembleDebug :wear:assembleDebug`（需要 JDK 17、Android SDK35、Gradle 8.10.2）。

**签名提醒：** `signing/watch8-development.jks` 是测试身份，仅用于私有仓库。升级前备份手机 API Key、监控列表、下单比分。原 APK 如采用不同签名，不能覆盖安装；不要为了测试直接卸载旧包导致本地配置丢失。

版本说明请参见 `CHANGELOG_ROUND_V38.md`；上一版本可靠通知同步方案详见 `CHANGELOG_NOTIFY_V37.md`。
