/* Matrix selections are local research metadata. Only the original native slots are emitted. */
(function(root){
 const exact=s=>/^[0-9]-[0-9]$/.test(s||'');
 const cell=s=>/^(?:[0-2]|3\+)-(?:[0-2]|3\+)$/.test(s||'');
 const group=s=>exact(s)?s.split('-').map(v=>+v>=3?'3+':v).join('-'):s;
 function normalize(rows){const seen=new Set();let main=false;return (Array.isArray(rows)?rows:[]).filter(b=>b&&(exact(b.pick)||cell(b.pick))&&!seen.has(b.pick)&&seen.add(b.pick)).map(b=>{const isMain=b.role==='主单'&&exact(b.pick)&&!main;if(isMain)main=true;return {...b,role:isMain?'主单':'保险'};});}
 function toggle(rows,score,double){rows=normalize(rows);if(!exact(score)&&!cell(score))return rows;const existing=rows.find(b=>b.pick===score);if(double&&exact(score)){rows=rows.map(b=>({...b,role:'保险'}));if(existing)rows=rows.filter(b=>b.pick!==score);return [{...(existing||{}),pick:score,role:'主单'},...rows];}if(existing)return rows.filter(b=>b.pick!==score);return [...rows,{pick:score,role:'保险',stake:0,offer:0,closed:false}];}
 function nativeRows(rows,n){rows=normalize(rows);const main=rows.find(b=>b.role==='主单');const backups=main?rows.filter(b=>b.role!=='主单'&&exact(b.pick)).slice(0,n-1):[];return Array.from({length:n},(_,i)=>{const b=i===0?main:backups[i-1];return {role:i===0?'主单':'保险'+i,pick:b?.pick||'',stake:Number(b?.stake||0),offer:Number(b?.offer||0),closed:!!b?.closed};});}
 function merge(rows,remote){const normalized=normalize(rows),active=normalize(remote);const picks=new Set(active.map(b=>b.pick));return [...active,...normalized.filter(b=>!picks.has(b.pick)).map(b=>({...b,role:'保险'}))];}
 const api={exact,cell,group,normalize,toggle,nativeRows,merge};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ScoreMatrix=api;
})(typeof globalThis!=='undefined'?globalThis:this);
