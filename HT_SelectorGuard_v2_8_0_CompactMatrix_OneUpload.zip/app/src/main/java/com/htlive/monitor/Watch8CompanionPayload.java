package com.htlive.monitor;

import org.json.JSONObject;
import org.json.JSONArray;

/** Single-screen data contract; shares the exact phone decision engine and alert formatter. */
public final class Watch8CompanionPayload {
    private Watch8CompanionPayload() {}
    public static JSONObject create(String id, int notificationId, String type, JSONObject match,
                                    long sampledAt, String fallback, boolean fresh) {
        return create(id,notificationId,type,match,sampledAt,fallback,fresh,"","");
    }
    public static JSONObject create(String id, int notificationId, String type, JSONObject match,
                                    long sampledAt, String fallback, boolean fresh,
                                    String phoneBody,String phoneDetail) {
        return create(id,notificationId,type,match,sampledAt,fallback,fresh,
            "","",phoneBody,phoneDetail);
    }
    /** Use exactly the same strings that the handset places in its Notification. */
    public static JSONObject create(String id, int notificationId, String type, JSONObject match,
                                    long sampledAt, String fallback, boolean fresh,
                                    String phoneTitle, String phonePreview,
                                    String phoneBody, String phoneDetail) {
        Watch8NotificationFormatter.Message formatted =
                Watch8NotificationFormatter.format(type, match, sampledAt, fallback);
        String[] lines = formatted.expanded.split("\n", -1);
        String status = lines.length > 2 ? lines[1] : "";
        String action = lines.length > 2 ? lines[2] :
            (lines.length > 1 ? lines[1] : "请核对手机赛况");
        String kind = formatted.title;
        String score = "?-?";
        if (match != null) {
            score = match.optString("h", "?") + "-" + match.optString("a", "?");
            String postfix = " " + score;
            if (kind.endsWith(postfix)) kind = kind.substring(0, kind.length()-postfix.length());
        }
        JSONObject guard = match == null ? null : match.optJSONObject("guardRisk");
        String level = guard == null ? "" : guard.optString("level", "");
        JSONArray picks = guard == null ? null : guard.optJSONArray("items");
        // Exact score selections come from the same guard engine used by the phone.
        // If a risk evaluation is temporarily absent, keep the selections without
        // inventing HIT/PENDING states.
        if (picks == null || picks.length() == 0)
            picks = match == null ? null : match.optJSONArray("guardBets");
        if (picks == null) picks = new JSONArray();
        JSONObject stats = match == null ? null : match.optJSONObject("stats");
        long statsAt = match == null ? 0L : match.optLong("lastStatsAt", 0L);
        boolean statsFresh = stats != null && stats.optBoolean("available", false) &&
            statsAt > 0 && sampledAt >= statsAt && sampledAt - statsAt <= 90000L;
        JSONObject review = match == null ? null : match.optJSONObject("aiReview");
        try { return new JSONObject()
            .put("v", 2).put("fixture", id).put("nid", notificationId)
            .put("kind", kind).put("period",match==null?"HT":match.optString("period","HT")).put("score", score)
            .put("line1", lines.length > 0 ? lines[0] : "赛况待核实")
            .put("line2", status).put("line3", action)
            .put("timed", formatted.timed).put("fresh", fresh).put("level", level)
            .put("time", System.currentTimeMillis())
            .put("sourceAt",match==null?sampledAt:match.optLong("fixtureSampledAt",sampledAt))
            .put("statsAt",match==null?0L:match.optLong("lastStatsAt",0L))
            .put("teams",match==null?"比赛 #"+id:match.optString("home", "主队")+" vs "+match.optString("away","客队"))
            .put("minute",match==null?-1:match.optInt("minute",-1))
            .put("bets",picks)
            .put("riskTitle",guard==null?"":guard.optString("title", ""))
            .put("riskAction",guard==null?"":guard.optString("action", ""))
            .put("aiAction",review==null?"":review.optString("action", ""))
            .put("statsFresh",statsFresh)
            .put("phoneTitle",phoneTitle==null||phoneTitle.isEmpty()?formatted.title:phoneTitle)
            .put("phonePreview",phonePreview==null||phonePreview.isEmpty()?formatted.preview:phonePreview)
            .put("phoneBody",phoneBody==null||phoneBody.isEmpty()?formatted.expanded:phoneBody)
            .put("phoneDetail",phoneDetail==null?"":phoneDetail);
        } catch (Exception e) { throw new IllegalStateException("Cannot serialize watch payload", e); }
    }
}
