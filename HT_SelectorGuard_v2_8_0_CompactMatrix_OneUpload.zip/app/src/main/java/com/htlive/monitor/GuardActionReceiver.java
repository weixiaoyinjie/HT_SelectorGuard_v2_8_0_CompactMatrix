package com.htlive.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Human acknowledgment and bounded, score-sensitive re-alerts while service is running. */
public final class GuardActionReceiver extends BroadcastReceiver {
    private static String key(String id){return "guard_pending_"+id;}
    public static void arm(Context context,String id,String type,JSONObject match,long now){
        try{
            JSONObject pending=new JSONObject().put("score",match.optInt("h")+"-"+match.optInt("a"))
                .put("type",type).put("created",now).put("last",now).put("attempts",0).put("ack",false);
            context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE).edit()
                .putString(key(id),pending.toString()).apply();
        }catch(Exception ignored){}
    }
    public static void disarm(Context context,String id){
        context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE).edit().remove(key(id)).apply();
    }
    public static boolean isAcknowledged(Context context,String id){
        try{return new JSONObject(context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE)
            .getString(key(id),"{}")).optBoolean("ack",false);}
        catch(Exception ignored){return false;}
    }
    public static void repeatIfUnacknowledged(Context context,String id,JSONObject match,long now){
        SharedPreferences p=context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        try{
            JSONObject state=new JSONObject(p.getString(key(id),"{}"));
            if(state.optBoolean("ack")||state.optLong("created")<=0)return;
            if(!"1H".equals(match.optString("status")))return;
            String score=match.optInt("h")+"-"+match.optInt("a");
            JSONObject guard=match.optJSONObject("guardRisk");
            if(!score.equals(state.optString("score"))||guard==null||
                !("HIGH".equals(guard.optString("level"))||"WATCH".equals(guard.optString("level"))))return;
            if(state.optInt("attempts")>=2 || now-state.optLong("last")<150_000L)return;
            // Never repeat an alert based on missing/stale statistics.
            if(match.optLong("lastStatsAt")<=0||now-match.optLong("lastStatsAt")>90_000L)return;
            state.put("attempts",state.optInt("attempts")+1).put("last",now);
            p.edit().putString(key(id),state.toString()).apply();
            AlertNotifier.post(context,"🔔 未确认 · 守分风险仍在",id,match,now,
                "此前的重要风险提醒尚未确认；如果已处理可在通知中点“已查看”。不是自动结算。");
        }catch(Exception ignored){}
    }
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null || !"GUARD_ACK".equals(intent.getAction()))return;
        String id=intent.getStringExtra("id");if(id==null||!id.matches("[0-9]{1,12}"))return;
        SharedPreferences p=context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        try{
            JSONObject state=new JSONObject(p.getString(key(id),"{}"));
            if(state.optLong("created")<=0)return;
            state.put("ack",true);
            p.edit().putString(key(id),state.toString()).apply();
        }catch(Exception ignored){}
    }
}
